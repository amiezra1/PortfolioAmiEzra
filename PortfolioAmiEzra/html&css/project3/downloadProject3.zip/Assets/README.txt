
1. Installation instructions: All files need to be downloaded
2. Operating instructions: The project3.html file must be opened using a browser
3. A file manifest (a list of files in the directory or archive):
  a. project3.html
  b. style.css
  C. Image:
    1)TreesOnWater.jpg
    2)SunsetTwoWomen.jpg
    3)BeachAndTree.jpg
    4)cowAndSea.jpg
    5)ForestAndFog.jpg
    6)branchesOnHead.jpg
    7)Sunset.jpg
    8)TropicalForest.jpg
    9)Monkey.jpg
    10)SleepyMan.jpg
    11)Hills.jpg
    12)Train.jpg
    13)GoldenDome.jpg
    14)Boat.jpg
4. Copyright and licensing information:
  All copyright belongs to Ami Ezra
5. Contact information for the distributor or author: 
  Ami Ezra 
  Email: ami@zvialod.com
  phone number: 052-3599918
6. A list of known bugs: none
7. Troubleshooting instructions: none
8. Credits and acknowledgments:
  Ami Ezra
9. A changelog:
  Creating a project- 27.12.2023
  Takeoff- 27.01.2023