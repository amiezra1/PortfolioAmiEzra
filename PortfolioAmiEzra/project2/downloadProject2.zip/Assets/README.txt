
1. Installation instructions: All files need to be downloaded
2. Operating instructions: The project2.html file must be opened using a browser
3. A file manifest (a list of files in the directory or archive):
  a. project2.html
  b. style.css
  C. Image:
    1)Group198.png
    2)Path152.png
4. Copyright and licensing information:
  All copyright belongs to Ami Ezra
5. Contact information for the distributor or author: 
  Ami Ezra 
  Email: ami@zvialod.com
  phone number: 052-3599918
6. A list of known bugs: none
7. Troubleshooting instructions: none
8. Credits and acknowledgments:
  Ami Ezra
9. A changelog:
  Creating a project- 27.12.2023
  Takeoff- 27.01.2023